import express from 'express';
import axios from 'axios';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';

// Get the current file path and directory name for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5000;

// Serve static files from the 'dist' directory (React build output)
app.use(express.static(path.join(__dirname, 'dist')));

app.use(cors());
app.use(express.json()); // Middleware to parse JSON

// API endpoint to send SMS
app.post('/api/send-sms', async (req, res) => {
  const smsPayload = req.body;

  try {
    // Forward the request to the external SMS API
    const response = await axios.post(
      'https://quicksms.advantasms.com/api/services/sendsms/',
      smsPayload,
      {
        headers: {
          'Content-Type': 'application/json',
        },
      }
    );
    res.json(response.data); // Return the SMS API response
  } catch (error) {
    console.error("Error sending SMS:", error);
    res.status(error.response?.status || 500).json(error.response?.data || error.message);
  }
});

// Serve React frontend for any other route (React handles routing)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

// Start the backend server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
